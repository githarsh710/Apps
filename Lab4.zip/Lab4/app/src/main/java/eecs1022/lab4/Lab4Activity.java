package eecs1022.lab4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class Lab4Activity extends AppCompatActivity {
Bank bank = new Bank();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab4);
    }


    private void displayThis(int id, String newContent){
        View view = findViewById(id);
        TextView textview = (TextView) view;
        textview.setText(newContent);
    }
    private String getInput(int id){
        View view = findViewById(id);
        EditText editText = (EditText) view;
        String input = editText.getText().toString();
        return input;
    }
    private String getSelectedInput(int id){
        View view = findViewById(id);
        Spinner spinner = (Spinner) view;
        String mySpinner = spinner.getSelectedItem().toString();
        return mySpinner;
    }



    public void CreateAccounts(View view){
        Client client1 = new Client(getSelectedInput(R.id.nameClient1),
                Double.parseDouble(getSelectedInput(R.id.InitialBalanceClient1)));
        Client client2 = new Client(getSelectedInput(R.id.nameClient2),
                Double.parseDouble(getSelectedInput(R.id.InitialBalanceClient2)));
        Client client3 = new Client(getSelectedInput(R.id.nameClient3),
                Double.parseDouble(getSelectedInput(R.id.InitialBalanceClient3)));

        bank.addClient(client1,client2,client3);

        displayThis(R.id.displayOne, client1.displayInfo());
        displayThis(R.id.displayTwo, client2.displayInfo());
        displayThis(R.id.displaythree, client3.displayInfo());
    }


    public void finishTransaction(View View){
        String service = getInput(R.id.spinner) ;
        String client =getInput(R.id.spinner2);
        String optional =getInput(R.id.spinner5);
        double money = Double.parseDouble(getInput(R.id.amount));
        bank.checkService(service, client, optional,money);


        displayThis(R.id.displayOne, bank.client1.displayInfo());
        displayThis(R.id.displayTwo, bank.client2.displayInfo());
        displayThis(R.id.displaythree, bank.client3.displayInfo());
    }


}
