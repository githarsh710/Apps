package eecs1022.lab4;

/**
 * Created by mailh on 2018-02-26.
 */

public class classTester {


    public static void main(String arg[]){
        Client c1 = new Client("Bob", 100);
        Client c2 = new Client("Poop", 50);
        Client c3 = new Client("Joe", 10);
        System.out.println(c1.displayInfo());
        System.out.println(c2.displayInfo());
        System.out.println(c3.displayInfo());
        System.out.println("\n");

        Bank bank = new Bank();
        bank.addClient(c1,c2,c3);

        bank.checkService("Transfer", "Client1", "Client2",10);
        System.out.println(c1.displayInfo());
        System.out.println(c2.displayInfo());
        bank.checkService("Transfer", "Client2", "Client3",10);
        System.out.println(c2.displayInfo());
        System.out.println(c3.displayInfo());
        bank.checkService("Transfer", "Client3", "Client1",10);
        System.out.println(c3.displayInfo());
        System.out.println(c1.displayInfo());
        System.out.println("\n");
        bank.checkService("Withdraw", "Client3", "",200);
        bank.checkService("Transfer", "Client3", "Client2",200);
        System.out.println(c1.displayInfo());
        System.out.println(c2.displayInfo());
        System.out.println(c3.displayInfo());
        System.out.println(c2.displayInfo());
    }


}
