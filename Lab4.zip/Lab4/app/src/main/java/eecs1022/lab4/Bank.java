package eecs1022.lab4;

/**
 * Created by mailh on 2018-02-26.
 */

public class Bank {
    Client client1;
    Client client2;
    Client client3;

    Bank(){

    }

    public void addClient(Client a,Client b,Client c){
        this.client1 = a;
        this.client2 = b;
        this.client3 = c;
    }



    public void depositMoney(Client x, double amount)
    {
        x.balance += amount;
    }
    public void withdrawMoney(Client x, double amount)
    {
        x.balance -= amount;
    }
    public void transferMoney(Client from,Client to, double amount){
        withdrawMoney(from, amount);
        depositMoney(to,amount);
    }

    public void checkService(String service, String client, String optional,double money){
        if (service.equals("Deposit")){
            if (client.equals("Client1")){
                depositMoney(client1, money);
            }
            else if (client.equals("Client2")){
                depositMoney(client2, money);
            }
            else if (client.equals("Client3")){
                depositMoney(client3, money);
            }
        }
        else if (service.equals("Withdraw")){
            if (client.equals("Client1")){
                withdrawMoney(client1, money);
            }
            else if (client.equals("Client2")){
                withdrawMoney(client2, money);
            }
            else if (client.equals("Client3")){
                withdrawMoney(client3, money);
            }
        }
        else if (service.equals("Transfer")){
            if (client.equals("Client1")){
                if (optional.equals("Client2")){
                    transferMoney(client1,client2,money);
                }
                else if (optional.equals("Client3")){
                    transferMoney(client1,client3,money);
                }
            }
            else if (client.equals("Client2")){
                if (optional.equals("Client1")){
                    transferMoney(client2,client1,money);
                }
                else if (optional.equals("Client3")){
                    transferMoney(client2,client3,money);
                }
            }

            else if (client.equals("Client3")){
                if (optional.equals("Client1")){
                    transferMoney(client3,client1,money);
                }
                else if (optional.equals("Client2")){
                    transferMoney(client3,client2,money);
                }
            }
        }
    }
}