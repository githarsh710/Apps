package eecs1022.lab4;

/**
 * Created by mailh on 2018-02-26.
 */

public class Client {

    String name;
    double balance;

    Client(String n, double b){
        this.name = n;
        this.balance = b;
    }

    public String displayInfo(){
        String c =String.format("%.2f", this.balance);
        String ret = "Client " + this.name + " Has Balance " + c;
        return ret;
    }


}