
import java.util.*;



/** This program has many methods which support the game.
 * @author Harsh patel 
 * @version 8.1
 */
public class Pokefight {
    private ArrayList<Object> Player1 = new ArrayList<Object>();
    private ArrayList<Object> Player2 = new ArrayList<Object>();
    private Pokemon name;
    
    
    /** helps in the text based game by taking in arraylist and pokemon.
     * @param player1
     * @param player2
     * @param name 
     */
    public Pokefight(ArrayList player1, ArrayList player2, Pokemon name ){
        this.Player1 = player1;
        this.Player2 = player2;
        this.name = name;
    }
    
    /**determines type ( which pokemon is stronger against which)
     * @param pokename
     * @param pokename2
     * @return typefactor
     */
    public int type(Pokemon pokename, Pokemon pokename2){
        int typefactor = 0;
        if (pokename.getType() == "fire"){ // gets type
            if(pokename2.getType() == "water"){ // compared the type to determine which one is superior
                typefactor = 2 ;    // attack pt affects 
            }
            
            else
            {
                typefactor = 1;
            }   
        }
        
        else if (pokename.getType() == "water"){ // gets type
                if (pokename2.getType() == "electric") { // compared the type to determine which one is superior
                    typefactor = 2;    // attack pt affects 
                }
                else {
                    typefactor = 1;
                }
        }
        
        else if (pokename.getType() == "grass"){ //gets type
                if (pokename2.getType() == "fire") { // compared the type to determine which one is superior
                    typefactor = 2;    // attack pt affects 
                }
                else {
                    typefactor = 1;
                }
                
        }
        
        else {
            typefactor = 1;
        }
        
        return typefactor; // returns typefactor value 
            
    }
    
    /** Determines the attack name according to pokemon type
     * @param poke
     * @return attackname
     */
    public String attackgenerator(Pokemon poke){
        String attackname = "null"; // initialised the attackname
        
        if (poke.getType() == "grass"){
            attackname = "seed bomb"; // for grass type attacks only
        }
        
        else if ( poke.getType() == "fire"){
            attackname = "flame thrower"; // for fire type attacks aonly
        }
        
        else if ( poke.getType() == "water"){
            attackname = "water gun"; // for water type attacks only
        }
        
        else if (poke.getType() == "electric"){
            attackname = " thunder bolt"; // for electric attack only
        }
        
        return attackname;
    }
   
    /**takes in 2 pokemons and decides which pokemon wins the battle.
     * @param poke1
     * @param poke2
     * @return winner
     */
    public String battle(Pokemon poke1 , Pokemon poke2){
        boolean a = true;
        String winner = "null" ; // retuen value is string ( initialised winner(string)).
        if ( poke1.getSpeed() >= poke2.getSpeed() ){ // if pokemon1 speed greater than pokemon 2 than pokemon 1 attacks first.
            while (a == true)
            {
                 int r = (int) (Math.random() * (100 - 0)) + 0; // to determine what the pokemon does 
                if ( r <= 20 ){ // 20% chance that this will happen
                    System.out.println(poke2.getName() + " dodged " + poke1.getName()); // attack dodged
                }
                
                else if (r > 20 && r <= 30 ){ // 10% chance for heal
                    poke2.setHealthleft( poke2.getHealthleft() + 10 );
                    System.out.println( poke2.getName() + " gets awarded heal "); // increases health
                }
                
                else {
                    poke2.setHealthleft( poke2.getHealthleft() - (poke1.getAttackpt()* type(poke1, poke2) ) ); // how thw attack works
                    System.out.println(poke1.getName() + " uses " + attackgenerator(poke1)); // for attack name
                }
                
               if ( poke2.getHealthleft() < 0){ // checks if health is zero to determine the winner.
                    winner = poke1.getName();
                    a = false;
                
                    
                }
                
                r = (int) (Math.random() * (100 - 0)) + 0;
                if ( r <= 20 ){ // 20% chance of dodging
                    System.out.println(poke1.getName() + " dodged " + poke2.getName());
                }
                
                else if (r > 20 && r <= 30 ){ // 10% chance of getting heaalth
                    poke1.setHealthleft( poke1.getHealthleft() + 10 );
                    System.out.println(poke1.getName() + " gets awarded heal ");
                }
                
                else {
                    poke1.setHealthleft( poke1.getHealthleft() - (poke2.getAttackpt()* type(poke2, poke1) ) ); // hwow attacj works
                    System.out.println(poke2.getName()+ "  uses  "  + attackgenerator(poke2)); // for attack name
                }
            
                if ( poke1.getHealthleft() < 0){ // checks if health is zero to determine the winner.
                    winner = poke2.getName();
                    a = false; // ends loop
                    
                }
               
                
            }
        }
        else if (poke1.getSpeed() <= poke2.getSpeed()) { // if pokemon 2 speed greatee than poke 1 then pokemon 2 attacks first
            while (a == true){
                int r = (int) (Math.random() * (100 - 0)) + 0;
                if ( r <= 20 ){ // 20% dodge rate
                    System.out.println(poke1.getName() + " dodged " + poke2.getName()); // dodges
                }
                
                else if (r > 20 && r <= 30 ){ // 10% heal rate
                    poke1.setHealthleft( poke1.getHealthleft() + 10 ); 
                    System.out.println(poke1.getName() + " gets awarded heal "); // gets heal
                }
                
                else {
                    poke1.setHealthleft( poke1.getHealthleft() - (poke2.getAttackpt()* type(poke2, poke1) ) ); // attacks
                    System.out.println( poke2.getName() + " uses  "  + attackgenerator(poke2));
                }
                
                if ( poke1.getHealthleft() <= 0){ // ends is pokeon1 health is zero
                    winner = poke2.getName();
                    a = false;
                }
                
                r = (int) (Math.random() * (100 - 0)) + 0;
                if ( r <= 20 ){
                    System.out.println(poke2.getName() + " dodged " + poke1.getName()); // dodges
                }
                
                else if (r > 20 && r <= 30 ){ // 10% chance of heal
                    poke1.setHealthleft( poke1.getHealthleft() + 10 );
                    System.out.println( poke2.getName() + " gets awarded heal "); // gets healed
                }
                
                else {
                    poke2.setHealthleft( poke2.getHealthleft() - (poke1.getAttackpt()* type(poke1, poke2) ) ); // attacks
                    System.out.println(poke1.getName() + " uses " +  attackgenerator(poke1));
                }
                 
                
                if ( poke2.getHealthleft() <= 0){ // checks pokemon 2 health and ends if 0
                    winner = poke1.getName();
                    a = false;
                
                    
                }
               
            }
        }
        return winner; 
        
    }
    
   
    
}
