/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Initiates pokemons
 *
 * @author Harsh patel
 * @version 8.1
 */
public class Pokemon {

    private String name;
    private String type;
    private int healthleft;
    private int healthtotal;
    private int attackpt;
    private int speed;

    /**
     * initiates pokemons
     * @param name
     * @param type
     * @param healthleft
     * @param healthtotal
     * @param attackpt
     * @param speed
     */
    public Pokemon(String name, String type, int healthleft, int healthtotal, int attackpt, int speed) {
        this.name = name;
        this.type = type;
        this.healthleft = healthleft;
        this.healthtotal = healthtotal;
        this.attackpt = attackpt;
        this.speed = speed;

    }

    /**gets the speed of the pokemon
     * @return speed
     */
    public int getSpeed() {
        return speed;
    }

    
    /** Sets the speed.
     * @param speed
     */
    public void setSpeed(int speed) {
        this.speed = speed;
    }

    
    /** gets the attack pt 
     * @return attackpt
     */
    public int getAttackpt() {
        return attackpt;
    }

    
    /** sets attack point 
     * @param attackpt 
     */
    public void setAttackpt(int attackpt) {
        this.attackpt = attackpt;
    }

    
    /** gets name 
     * @return name
     */
    public String getName() {
        return name;
    }

    
    /** sets name of pokemon
     * @param name 
     */
    public void setName(String name) {
        this.name = name;
    }

    
    /** gets type
     * @return type
     */
    public String getType() {
        return type;
    }

    
    /** sets type of pokemon
     * @param type 
     */
    public void setType(String type) {
        this.type = type;
    }

    
    /** gets healthleft
     * @return healthleft
     */
    public int getHealthleft() {
        return healthleft;
    }

    
    /** sets healthleft
     * @param healthleft 
     */
    public void setHealthleft(int healthleft) {
        this.healthleft = healthleft;
    }

    
    /** gets total health
     * @return totalhealth
     */
    public int getHealthtotal() {
        return healthtotal;
    }
    

    /** sets healthtotal
     * @param healthtotal 
     */
    public void setHealthtotal(int healthtotal) {
        this.healthtotal = healthtotal;
    }

    
    /** to string method
     * @return name
     * @return type
     * @return healthleft
     * @return healthtotal
     * @return speed
     * @return attackpt
     */
    @Override
    public String toString() {
        return "Pokemon{" + "name = " + name + ", type = " + type + ", healthleft = "
                + healthleft + ", healthtotal = " + healthtotal + ", attackpt = "
                + attackpt + ", speed = " + speed + '}';
    }

}
