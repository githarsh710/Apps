
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/** The pokemon game.
 * @author Harsh patel 
 * @version 8.1
 */
public class pokemonmain {
    
    /** the main method of the game
     * @param args 
     */
    public static void main(String[] args) {
        Pokemon pikachu = new Pokemon("pikachu", "electric", 60, 60, 10 , 18);
        Pokemon charmander = new Pokemon("charmander", "fire", 80, 80, 12 , 12);
        Pokemon bulbasor = new Pokemon("bulbasor", "grass", 65, 65, 11 , 13);
        Pokemon vaporeon = new Pokemon("vaporeon", "water", 70, 70, 11, 14 );
        Pokemon flareon = new Pokemon("flareon", "fire", 50, 50, 15 , 10);
        Pokemon goldeen = new Pokemon("goldeen", "water", 50, 50, 20 , 2);
        Pokemon squirtle = new Pokemon("squirtle", "water", 67, 67, 12 , 16);
        Pokemon pichu = new Pokemon("pichu", "electric", 64, 64, 10 , 11);
        Pokemon vulpix = new Pokemon("vulpix", "fire", 70, 70, 15 , 7);
        // initaites pokemons
        
        // make arraylist to store pokemons of both the players.
        ArrayList<Object> Player1 = new ArrayList<Object>();
        ArrayList<Object> Player2 = new ArrayList<Object>();
        Scanner in = new Scanner(System.in);
        
        
        // call the class pokefight
        Pokefight p = new Pokefight (Player1, Player2, pikachu);
                        
                
        System.out.println("welcome to the poke-game" );
        //delays the game. (for gamming effects)
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(pokemonmain.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        System.out.println("player 1 select your pokemon");
        
        //delays the game. (for gamming effects)
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(pokemonmain.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        System.out.println(" these are your choices");
        System.out.println("pikachu, charmander, bulbasor, vaporeon, "
                + "falreon, goldenpikachu, goldeen, squirtle, pichu, vulpix");
        // informs the user about which pokemons the game posses.
        
        //delays the game. (for gamming effects)
        try {
            Thread.sleep(1500);
        } catch (InterruptedException ex) {
            Logger.getLogger(pokemonmain.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // lets the user select their pokemon
        System.out.println("which pokemon will u like ");
        // user has to enter numbers, this to reduce work (users are lazy).
        System.out.println("enter 1 for pikachu");
        System.out.println("enter 2 for charmander");
        System.out.println("enter 3 for bulbasor");
        System.out.println("enter 4 for vaporeon");
        System.out.println("enter 5 for flareon");
        System.out.println("enter 6 for goldeen");
        System.out.println("enter 7 for squrtle");
        System.out.println("enter 8 for pichu");
        System.out.println("enter 9 for vulpix");
        System.out.println("");
        System.out.println("enter first pick");
        int fpick = in.nextInt();
        System.out.println("");// blank print statement to make it look clean
        System.out.println("enter second pick");
        int spick = in.nextInt();
        System.out.println("");
        System.out.println("third pick ");
        int tpick = in.nextInt();
        
        // the first selection of the user (player 1)
        if (fpick == 1) {
            Player1.add(pikachu);
        } else if (fpick == 2) {
            Player1.add(charmander);

        } else if (fpick == 3) {
            Player1.add(bulbasor);

        } else if (fpick == 4) {
            Player1.add(vaporeon);

        } else if (fpick == 5) {
            Player1.add(flareon);

        } else if (fpick == 6) {
            Player1.add(goldeen);

        } else if (fpick == 7) {
            Player1.add(squirtle);

        } else if (fpick == 8) {
            Player1.add(pichu);

        } else if (fpick == 9) {
            Player1.add(vulpix);
        }

        
        // second selection of the user (player 1).
        if (spick == 1) {
            Player1.add(pikachu);
        } else if (spick == 2) {
            Player1.add(charmander);

        } else if (spick == 3) {
            Player1.add(bulbasor);

        } else if (spick == 4) {
            Player1.add(vaporeon);

        } else if (spick == 5) {
            Player1.add(flareon);

        } else if (spick == 6) {
            Player1.add(goldeen);

        } else if (spick == 7) {
            Player1.add(squirtle);

        } else if (spick == 8) {
            Player1.add(pichu);

        } else if (spick == 9) {
            Player1.add(vulpix);
        }

        
        // third selection of the user (player 1).
        if (tpick == 1) {
            Player1.add(pikachu);
        } else if (tpick == 2) {
            Player1.add(charmander);

        } else if (tpick == 3) {
            Player1.add(bulbasor);

        } else if (tpick == 4) {
            Player1.add(vaporeon);

        } else if (tpick == 5) {
            Player1.add(flareon);

        } else if (tpick == 6) {
            Player1.add(goldeen);

        } else if (tpick == 7) {
            Player1.add(squirtle);

        } else if (tpick == 8) {
            Player1.add(pichu);

        } else if (tpick == 9) {
            Player1.add(vulpix);

        }

        // player 2 's turn to select pokemon
        System.out.println("player 2 select your pokemon");
        
        //delays the game. (for gamming effects)
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(pokemonmain.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.println(" these are your choices");
        System.out.println("pikachu, charmander, bulbasor, vaporeon, falreon, goldenpikachu, goldeen, squirtle, pichu, vulpix");
        
        //delays the game. (for gamming effects)
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(pokemonmain.class.getName()).log(Level.SEVERE, null, ex);
        }
        // player 2's pokemon slection
        System.out.println("which pokemon will u like ");
        System.out.println("enter 1 for pikachu");
        System.out.println("enter 2 for charmander");
        System.out.println("enter 3 for bulbasor");
        System.out.println("enter 4 for vaporeon");
        System.out.println("enter 5 for flareon");
        System.out.println("enter 6 for goldeen");
        System.out.println("enter 7 for squrtle");
        System.out.println("enter 8 for pichu");
        System.out.println("enter 9 for vulpix");
        System.out.println("");
        System.out.println("enter first pick"); // first pick
        int f2pick = in.nextInt();
        System.out.println("");
        System.out.println("enter second pick"); // second pick 
        int s2pick = in.nextInt();
        System.out.println("");
        System.out.println("third pick ");  // third pick
        int t2pick = in.nextInt();

        // first pick selection.
        if (f2pick == 1) {
            Player2.add(pikachu);
        } else if (f2pick == 2) {
            Player2.add(charmander);

        } else if (f2pick == 3) {
            Player2.add(bulbasor);

        } else if (f2pick == 4) {
            Player2.add(vaporeon);

        } else if (f2pick == 5) {
            Player2.add(flareon);

        } else if (f2pick == 6) {
            Player2.add(goldeen);

        } else if (f2pick == 7) {
            Player2.add(squirtle);

        } else if (f2pick == 8) {
            Player2.add(pichu);

        } else if (f2pick == 9) {
            Player2.add(vulpix);
        }

        
        // second pick selection
        if (s2pick == 1) {
            Player2.add(pikachu);
        } else if (s2pick == 2) {
            Player2.add(charmander);

        } else if (s2pick == 3) {
            Player2.add(bulbasor);

        } else if (s2pick == 4) {
            Player2.add(vaporeon);

        } else if (s2pick == 5) {
            Player2.add(flareon);

        } else if (s2pick == 6) {
            Player2.add(goldeen);

        } else if (s2pick == 7) {
            Player2.add(squirtle);

        } else if (s2pick == 8) {
            Player2.add(pichu);

        } else if (s2pick == 9) {
            Player2.add(vulpix);
        }

        
        // third pokeom selection
        if (t2pick == 1) {
            Player2.add(pikachu);
        } else if (t2pick == 2) {
            Player2.add(charmander);

        } else if (t2pick == 3) {
            Player2.add(bulbasor);

        } else if (t2pick == 4) {
            Player2.add(vaporeon);

        } else if (t2pick == 5) {
            Player2.add(flareon);

        } else if (t2pick == 6) {
            Player2.add(goldeen);

        } else if (t2pick == 7) {
            Player2.add(squirtle);

        } else if (t2pick == 8) {
            Player2.add(pichu);

        } else if (t2pick == 9) {
            Player2.add(vulpix);

        }

        
        // checks if player 1 has selected a pokemon twice 
        if (fpick == spick || spick == tpick || fpick == tpick) {
            System.out.println("sorry no cheating Player 1 , you cannot have same pokemon twice  ");
            System.exit(0);
        }
        

        // checks if player 2 has selected pokemon twice
        if (f2pick == s2pick || s2pick == t2pick || f2pick == t2pick) {
            System.out.println("sorry no cheating Player 2 , you cannot have same pokemon twice  ");
            System.exit(0);
        }
        
        
        // checks if all the pokemon are unique 
        // this is for first pick
        if (fpick == f2pick || fpick == s2pick || fpick == t2pick){
            System.out.println(" sorry you cant pick the same pokemons to fight ");
            System.exit(0);
            
        }
        
        
        // this is for second pick
        if (spick == f2pick || spick == s2pick || spick == t2pick){
            System.out.println(" sorry you cant pick the same pokemons to fight ");
            System.exit(0);
            
        }
        
        
        // this is for third pick
        if (tpick == f2pick || tpick == s2pick || tpick == t2pick){
            System.out.println(" sorry you cant pick the same pokemons to fight ");
            System.exit(0);
            
        }
        
        
        System.out.println("");

        
        // shows player1's pokemons 
        System.out.println(" player 1 these are your pick ");
        for (int a = 0; a < Player1.size(); a++) {
            System.out.println(Player1.get(a));

        }
        
        // delay to give gamming effect 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(pokemonmain.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.println("");

        // shows player 2 pokemons
        System.out.println(" player 2 these are your pick ");
        for (int b = 0; b < Player2.size(); b++) {
            System.out.println(Player2.get(b));
        }
        
        // delay to give gamming effect
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(pokemonmain.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.println("");
        System.out.println("");
        
        int a = 0;// for player1(index number)
        int b = 0;// for player 2 (index number)
        Pokemon temp1 = (Pokemon) Player1.get(a); // puts into temp1
        Pokemon temp2 = (Pokemon) Player2.get(b); // puts into temp2
        String name = " null ";
        
        System.out.println("round 1 ");
        System.out.println(temp1.getName() + "  vs  " + temp2.getName());
        System.out.println("");
        name = p.battle(temp1, temp2); // call pokefight method battle .
        System.out.println(name + " wins!! ");
        
        boolean runner = true; // for while loop
        int counter = 2; // for round numbers (starts with 2 cuz round 1 is done already)
        System.out.println("");
        
        while( runner = true){
            
            // delay for gamming effect
            try {
                Thread.sleep(1500);
            } catch (InterruptedException ex) {
                Logger.getLogger(pokemonmain.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            // checks if the returened name is in player 1 then , player 1 pokemon won and the next pokemon to battle it would be from player 2.
            if (temp1.getName() == (String) name) {
                System.out.println("");
                System.out.println("");
                b++;
        
                if (b == 3) { // if index number =3 then it will end as player 2 no longer has any pokemons left.
                    System.out.println("player 1 wins "); // hence plater 1 wins.
                    break;

                }
                temp2 = (Pokemon) Player2.get(b);
                System.out.println("round " + counter); // states round number 
                System.out.println(temp1.getName() + "  vs  " + temp2.getName());
                System.out.println("");
                name = p.battle(temp1, temp2); //battle
                System.out.println(name + " wins!! ");
                counter++; // increaments counter value by 1.
   
            }
            // checks id the returned name is from player 2, then player 2 win and the next pokemon from player 1 will battle it.
            else if (temp2.getName() == (String) name) {
                System.out.println("");
                System.out.println("");
                a++;
                
                if (a == 3) {// if index number =3 then it will end as player 2 no longer has any pokemons left.
                    System.out.println("player 2 wins "); // hence player 2 wins 
                    break;

                }
                
                temp1 = (Pokemon) Player1.get(a);
                System.out.println("round " + counter);  // states round number 
                System.out.println(temp1.getName() + "  vs  " + temp2.getName());
                System.out.println("");
                name = p.battle(temp1, temp2); // battle
                System.out.println(name + " wins !!");
                counter++;  // increaments counter value by 1.

            }
            
        }
        

    } 

}

