package eecs1022.lab6;

/**
 * Created by mailh on 2018-04-14.
 */

public class tester {
    public static void main(String[] args ){
        Game game = new Game();

        game.setPx("Harsh");
        game.setPo("Jack");
        game.setCurrentplayer("X");
        System.out.println(game.Start());


        game.Gameplay(1,2);
        System.out.println(game.tostring());

        game.Gameplay(2,3);
        System.out.println(game.tostring());


        game.Gameplay(2,2);
        System.out.println(game.tostring());


        game.Gameplay(1,3);
        System.out.println(game.tostring());

        game.Gameplay(1,3);
        System.out.println(game.tostring());


        game.Gameplay(3,2);
        System.out.println(game.tostring());


        game.Gameplay(0,1);
        System.out.println(game.tostring());




    }
}
