package eecs1022.lab6;

/**
 * Created by mailh on 2018-04-14.
 */

public class Game {

    char board[][]= new char[3][3];
    String Px = null;
    String Po = null;
    int row = -1;
    int col = -1;
    boolean gp = false;
    boolean ow= false;
    String fp = null;
    String currentplayer = null;
    int turn = 0;
    int gm = 0;
    boolean first = true;

    Game(){

    }

    public boolean isGp() {
        return gp;
    }

    public void setPo(String po) {
        Po = po;
    }

    public void setPx(String px) {
        Px = px;
    }

    public void setCol(int col) {
        this.col = col-1;
    }

    public void setRow(int row) {
        this.row = row-1;
    }

    // makes a new board (start/Restart Button)
    String Start(){
        String a = "";
        for(int b = 0; b<3; b++){
            for (int c = 0; c<3; c++){
                board[b][c]='.';
                a = a + board[b][c];
            }
            a = a + "\n";

        }
        if(first){
            if (turn % 2 != 0) {
                a = a + "First Player to Play is " + this.Po + "\n";
            } else if (turn % 2 == 0) {
                a = a + "First Player to Play is " + this.Px + "\n";
            }

        }

        return a;
    }
    // prints out board
    String board(){
        String a = "";
        for(int b = 0; b<3; b++){
            for (int c = 0; c<3; c++){
                a = a + board[b][c];
            }
            a = a + "\n";

        }

        return a;
    }

    String tostring() {
        String a = board();

        if (gp==false) {

            if (!ow) {

                if (turn % 2 != 0) {
                    a = a + "Next Player to Play is " + this.Po + "\n";
                } else if (turn % 2 == 0) {
                    a = a + "Next Player to Play is " + this.Px + "\n";
                }
            } else if (ow) {
                a = a + "Position is occupied ";
                ow = false;
                if (turn % 2 != 0) {
                    a = a + "Player " + this.Po + " Choose another position \n";
                } else if (turn % 2 == 0) {
                    a = a + "Player " + this.Px + " Choose another position \n";

                }
            }
            } else if (gp==true) {

                if(gm == 0){
                    if (turn % 2 == 0) {
                        a = a + "Player " + this.Po + " Is The Winner \n";
                    } else if (turn % 2 != 0) {
                        a = a + "Player " + this.Px + " Is The Winner \n";

                    }
                    gm = 1;
                }
                else if(gm ==1 ){
                    a = a + " GAME IS OVER!!";
                }


            }

            return a;
        }

        boolean Gameplay(int r, int c){
            setRow(r);
            setCol(c);
            if(gp==false){
            if (turn % 2 != 0) {
                setposO();
                WinO();
                // check if win or not gp = that
                if (!ow) {
                    turn++;
                }

            } else if (turn % 2 == 0) {
                setPosX();
                WinX();
                // check if win or not gp = that
                if (!ow) {//owerwrite
                    turn++;
                }
            }}



            return this.gp;
        }

    int getTurn(){
        return this.turn;
    }

    void WinO(){
        if(board[0][0]=='O' && board[0][1]=='O' && board[0][2]=='O' ){
            this.gp = true;
        }
        else if(board[0][0]=='O' && board[1][1]=='O' && board[2][2]=='O'){
            this.gp = true;
        }
        else if(board[0][0]=='O' && board[1][0]=='O' && board[2][0]=='O'){
            this.gp = true;
        }
        else if(board[0][1]=='O' && board[1][1]=='O' && board[2][1]=='O'){
            this.gp = true;
        }
        else if(board[0][2]=='O' && board[1][2]=='O' && board[2][2]=='O'){
            this.gp = true;
        }
        else if(board[1][0]=='O' && board[1][1]=='O' && board[1][2]=='O'){
            this.gp = true;
        }
        else if(board[2][0]=='O' && board[2][1]=='O' && board[2][2]=='O'){
            this.gp = true;
        }
        else if(board[0][2]=='O' && board[1][1]=='O' && board[2][0]=='O'){
            this.gp = true;
        }



    }

    void WinX(){
        if(board[0][0]=='X' && board[0][1]=='X' && board[0][2]=='X' ){
            this.gp = true;
        }
        else if(board[0][0]=='X' && board[1][1]=='X' && board[2][2]=='X'){
            this.gp = true;
        }
        else if(board[0][0]=='X' && board[1][0]=='X' && board[2][0]=='X'){
            this.gp = true;
        }
        else if(board[0][1]=='X' && board[1][1]=='X' && board[2][1]=='X'){
            this.gp = true;
        }
        else if(board[0][2]=='X' && board[1][2]=='X' && board[2][2]=='X'){
            this.gp = true;
        }
        else if(board[1][0]=='X' && board[1][1]=='X' && board[1][2]=='X'){
            this.gp = true;
        }
        else if(board[2][0]=='X' && board[2][1]=='X' && board[2][2]=='X'){
            this.gp = true;
        }
        else if(board[0][2]=='X' && board[1][1]=='X' && board[2][0]=='X'){
            this.gp = true;
        }



    }

    void setCurrentplayer(String name){
        if (name.equals("X")){
           this.turn = 2;
        }
        else if(name.equals("O")){
            this.turn = 1;
        }
        else {
            this.turn = 3;
        }
    }

    void setPosX(){
        if(board[row][col]=='.') {

            char x = 'X';
            board[row][col] = 'X';
        }
        else{
            this.ow = true;
        }
    }
    void setposO(){
        if(board[row][col]=='.') {
            char x = 'O';
            board[row][col] = 'O';
        }
        else{
            this.ow = true;
            }

        }

}

