package eecs1022.lab6;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class Lab6Activity extends AppCompatActivity {

    Game game;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab6);
    }


    private void displayThis(int id, String newContent){
        View view = findViewById(id);
        TextView textview = (TextView) view;
        textview.setText(newContent);
    }
    private String getInput(int id){
        View view = findViewById(id);
        EditText editText = (EditText) view;
        String input = editText.getText().toString();
        return input;
    }
    private String getSpinnerInput(int id){
        View view = findViewById(id);
        Spinner spinner = (Spinner) view;
        String mySpinner = spinner.getSelectedItem().toString();
        return mySpinner;
    }

    public void StartRestart(View view){
        game = new Game();
        game.setPx(getInput(R.id.PlayerX));
        game.setPo(getInput(R.id.PlayerO));
        game.setCurrentplayer(getSpinnerInput(R.id.spinner));
        displayThis(R.id.LabelAnswer,game.Start());


    }

    public void Play(View view){
        game.setRow(Integer.parseInt(getSpinnerInput(R.id.Row)));
        game.setCol(Integer.parseInt(getSpinnerInput(R.id.Col)));
        displayThis(R.id.LabelAnswer,game.tostring());
    }

}
